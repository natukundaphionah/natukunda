// Load environment variables from the .env file
require("dotenv").config();
require("@nomiclabs/hardhat-waffle");
require("@nomiclabs/hardhat-ethers");
/** @type import('hardhat/config').HardhatUserConfig */

// Replace these with your own Infura API key and wallet private key
//const INFURA_API_KEY = process.env.INFURA_API_KEY || "6VZD9BZC63WFHJNSECE6DCQSBY27KX71WE";
const PRIVATE_KEY = process.env.PRIVATE_KEY || "11485bd9167660e03d0ee21501939bfb738b997a4a6a898d0621f2f90c851267";

// Ensure that the PRIVATE_KEY is defined
if (!PRIVATE_KEY) {
  throw new Error("Please set your PRIVATE_KEY in a .env file");
}


module.exports = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  networks: {
    hardhat: {
      chainId: 1337,
    },
    bsc: {
      url: "https://bsc-dataseed.binance.org/", // BSC Mainnet RPC
      accounts: [`0x${PRIVATE_KEY}`], // Your wallet private key
      chainId: 56, // BSC Mainnet Chain ID
    },
    bsctestnet: {
      url: "https://data-seed-prebsc-2-s1.binance.org:8545/", // BSC Testnet RPC URL
      accounts: [`0x${PRIVATE_KEY}`], // Your wallet private key
      chainId: 97,} // BSC Testnet Chain ID
    // sepolia: {
    //   url: `https://sepolia.infura.io/v3/${INFURA_API_KEY}`, // Sepolia Testnet RPC via Infura
    //   accounts: [`0x${PRIVATE_KEY}`], // Your wallet private key
    //   chainId: 11155111, // Sepolia chain ID
    // },
    // rinkeby: {
    //   url: `https://rinkeby.infura.io/v3/${INFURA_API_KEY}`, // Rinkeby Testnet RPC via Infura
    //   accounts: [`0x${PRIVATE_KEY}`], // Your wallet private key
    //   chainId: 4, // Rinkeby chain ID
    // },
    // mainnet: {
    //   url: `https://mainnet.infura.io/v3/${INFURA_API_KEY}`,
    //   accounts: [`0x${PRIVATE_KEY}`],
    // },

  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
  },
  mocha: {
    timeout: 20000,
  },
};
