// // scripts/execute.js
// const { ethers } = require("hardhat");

// async function main() {
//     const [owner] = await ethers.getSigners(); // Get the signer

//     // Replace with the address of your deployed Arbitrage contract
//     const arbitrageAddress = "0xeF5C00960F6656aeA9204Bb5bf9d88A1730488Ec"; 
//     const Arbitrage = await ethers.getContractAt("Arbitrage", arbitrageAddress);

//     console.log("Interacting with Arbitrage contract at:", arbitrageAddress);

//     // Example: Call a function on the contract
//     // Replace 'executeArbitrage' with the actual function name you want to call
//     const tx = await Arbitrage.executeArbitrage(/* parameters if needed */);
    
//     // Wait for the transaction to be confirmed
//     await tx.wait();

//     console.log("Arbitrage executed successfully.");
// }

// main()
//     .then(() => process.exit(0))
//     .catch((error) => {
//         console.error(error);
//         process.exit(1);
//     });
const { ethers } = require("hardhat");

async function main() {
  const arbitrageAddress = "0xeF5C00960F6656aeA9204Bb5bf9d88A1730488Ec";
  const Arbitrage = await ethers.getContractAt("Arbitrage", arbitrageAddress);

  // Call a function that requires an argument, e.g., `executeArbitrage`
  const arg1 = 1; // example argument
  const tx = await Arbitrage.executeArbitrage(arg1);

  console.log("Transaction sent:", tx.hash);

  // Wait for the transaction to be confirmed
  await tx.wait();
  console.log("Transaction confirmed!");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
